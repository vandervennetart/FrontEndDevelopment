import { app } from "./app.js";

app.listen(3000, () => console.log(`server running on http://localhost:3000`));
